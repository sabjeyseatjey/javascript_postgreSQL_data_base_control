
const ApiError = require('../error/ApiError');


const { Booking, Guest, Room } = require('../models/models')


class BookingController {
    async create(req, res, next) {
        try {
            let {check_in_date, check_out_date, GuestId, RoomId  } = req.body;
        
            const Booking = await Booking.create({
              check_in_date,
              check_out_date,
              GuestId,
              RoomId,
            });
        
            return res.json(Booking);
          } catch (e) {
            next(ApiError.badRequest(e.message));
          }
    }


    async getAll(req, res, next) {
        try {
            const bookings = await Booking.findAll({
                include: [Guest, Room],
              });
          
              // Проходим по каждому бронированию и преобразуем информацию
              const formattedBookings = bookings.map((booking) => {
                return {
                  id: booking.id,
                  check_in_date: booking.check_in_date,
                  check_out_date: booking.check_out_date,
                  guest: {
                    id: booking.Guest.id,
                    firstname: booking.Guest.firstname,
                    lastname: booking.Guest.lastname,
                    email: booking.Guest.email,
                    // Другие свойства гостя
                  },
                  room: {
                    id: booking.Room.id,
                    room: booking.Room.room,
                    // Другие свойства номера
                  },
                };
              });
          
              // Возвращаем отформатированную информацию
          res.json(formattedBookings);
        } catch (error) {
          
          next(error);
        }
      }
      
    
}

module.exports = new BookingController()    

