const uuid = require('uuid')
const path = require('path');
const ApiError = require('../error/ApiError');
const { Op } = require('sequelize');



const {RoomType,
    Facilities,
    Nutrition,
    RoomAvailable,
    Room,
    RoomFacilities,
    } = require('../models/models')


class RoomController {
    async create(req, res, next) {
        try {
            let { room, description, price, room_count, maximum_person, RoomTypeId, RoomAvailableId, NutritionId } = req.body;
            const { img_1, img_2, img_3, img_4, img_5, img_6, img_7, img_8, img_9, img_10 } = req.files;
        
            const uploadImage = async (img) => {
              if (!img) return null;
              const fileName = uuid.v4() + '.jpg';
              await img.mv(path.resolve(__dirname, '..', 'static', fileName));
              return fileName;
            };
        
            const img_1_path = await uploadImage(img_1);
            const img_2_path = await uploadImage(img_2);
            const img_3_path = await uploadImage(img_3);
            const img_4_path = await uploadImage(img_4);
            const img_5_path = await uploadImage(img_5);
            const img_6_path = await uploadImage(img_6);
            const img_7_path = await uploadImage(img_7);
            const img_8_path = await uploadImage(img_8);
            const img_9_path = await uploadImage(img_9);
            const img_10_path = await uploadImage(img_10);
        
            const rooms = await Room.create({
              room,
              description,
              price,
              room_count,
              maximum_person,
              RoomTypeId,
              RoomAvailableId,
              NutritionId,
              img_1: img_1_path,
              img_2: img_2_path,
              img_3: img_3_path,
              img_4: img_4_path,
              img_5: img_5_path,
              img_6: img_6_path,
              img_7: img_7_path,
              img_8: img_8_path,
              img_9: img_9_path,
              img_10: img_10_path,
            });
        
            return res.json(rooms);
          } catch (e) {
            next(ApiError.badRequest(e.message));
          }
    }




    async getAll(req, res, next) {
      try {
        const searchCriteria = {
          facilities: req.query.facilities || [],
          nutrition: req.query.nutrition || '',
          roomType: req.query.roomType || '',
          isActive: req.query.isActive || true,
          maximumPerson: req.query.maximumPerson || 0,
          roomCount: req.query.roomCount || 0,
        };
    
        // Формируем массив include
        const includeArray = [];
    
        // Добавляем Nutrition, если у нас есть критерий по этому полю
        if (searchCriteria.nutrition !== '') {
          includeArray.push({
            model: Nutrition,
            where: { nutrition: searchCriteria.nutrition },
            attributes: ['id', 'nutrition', 'createdAt', 'updatedAt'],
          });
        }
    
        // Аналогично для RoomType
        if (searchCriteria.roomType !== '') {
          includeArray.push({
            model: RoomType,
            where: { room_type: searchCriteria.roomType },
            attributes: ['id', 'room_type', 'createdAt', 'updatedAt'],
          });
        }
    
        // И для RoomAvailable
        if (searchCriteria.isActive !== '') {
          includeArray.push({
            model: RoomAvailable,
            where: { is_active: searchCriteria.isActive },
            attributes: ['id', 'is_active', 'createdAt', 'updatedAt'],
          });
        }
    
        // Добавляем Facilities, если у нас есть критерии по этому полю
        if (Array.isArray(searchCriteria.facilities) && searchCriteria.facilities.length > 0) {
            // Если в массиве только один элемент, передаем его напрямую, иначе используем Op.in
            const facilitiesCondition = searchCriteria.facilities.length === 1
              ? { facilities: searchCriteria.facilities[0] }
              : { facilities: { [Op.in]: searchCriteria.facilities } };
          
            includeArray.push({
              model: Facilities,
              where: facilitiesCondition,
              attributes: ['id', 'facilities', 'createdAt', 'updatedAt'],
            });
          }
    
        // Формируем объект для where условий
        const whereConditions = {};
    
        // Добавляем условие, если оно было предоставлено в запросе
        if (searchCriteria.maximumPerson !== 0) {
          whereConditions.maximum_person = searchCriteria.maximumPerson;
        }
        
        // Аналогично для roomCount
        if (searchCriteria.roomCount !== 0) {
          whereConditions.room_count = searchCriteria.roomCount;
        }
    
        // Выполняем запрос только если есть хотя бы одно условие
        if (Object.keys(whereConditions).length > 0 || includeArray.length > 0) {
          const result = await Room.findAll({
            include: includeArray,
            where: whereConditions,
          });
    
          // Возвращаем результат в формате JSON
          res.json(result);
        } else {
          // Если нет условий, возвращаем пустой массив
          res.json([]);
        }
      } catch (error) {
        // Выводим ошибку в консоль для анализа
        console.error(error);
    
        // Отправляем ошибку клиенту
        res.status(500).json({ error: 'Internal Server Error' });
      }
    }
    
      
                      
      
      
    async getOne(req, res) {
        const roomId = req.params.id;
        const result = await Room.findOne({
            where: { id: roomId },
            include: [
              { model: Facilities, through: RoomFacilities },
              { model: Nutrition },
              { model: RoomType },
              { model: RoomAvailable },
            ],
          });
          
          return res.json(result);
    }
}

module.exports = new RoomController()    

