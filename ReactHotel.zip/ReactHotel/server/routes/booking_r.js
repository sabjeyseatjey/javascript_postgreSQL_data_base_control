const Router = require('express')
const router = new Router()
const BookingController = require('../controllers/booking_c')

router.post('/', BookingController.create)
router.get('/', BookingController.getAll)
// router.get('/:id', BookingController.getOne)



module.exports = router