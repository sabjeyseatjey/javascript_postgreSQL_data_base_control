const Router = require('express')
const router = new Router()
const RoomRouter = require('./room_r')
const BookingRouter = require('./booking_r')
const adminRouter = require('./admin_r')


router.use('/room', RoomRouter)
router.use('/bookings', BookingRouter)
router.use('/admin', adminRouter)

module.exports = router

