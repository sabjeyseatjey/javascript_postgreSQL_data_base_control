// models.js
const { DataTypes } = require('sequelize');
const sequelize = require('../db');

const Admin = sequelize.define('Admin', {
    id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
    email: {type: DataTypes.STRING, unique: true,},
    password: {type: DataTypes.STRING},
    role: {type: DataTypes.STRING, defaultValue: "Admin"},
})


const RoomType = sequelize.define('RoomType', {
  room_type: {
    type: DataTypes.STRING,
    allowNull: false,
  },
});

const Facilities = sequelize.define('Facilities', {
  facilities: {
    type: DataTypes.STRING,
    allowNull: false,
  },
});

const Nutrition = sequelize.define('Nutrition', {
  nutrition: {
    type: DataTypes.STRING,
    allowNull: false,
  },
});

const RoomAvailable = sequelize.define('RoomAvailable', {
  is_active: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
  },
});

const Room = sequelize.define('Room', {
  room: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  description: {
    type: DataTypes.STRING,
  },
  price: DataTypes.STRING,
  img_1: DataTypes.STRING,
  img_2: DataTypes.STRING,
  img_3: DataTypes.STRING,
  img_4: DataTypes.STRING,
  img_5: DataTypes.STRING,
  img_6: DataTypes.STRING,
  img_7: DataTypes.STRING,
  img_8: DataTypes.STRING,
  img_9: DataTypes.STRING,
  img_10: DataTypes.STRING,
  room_count: {
    type: DataTypes.INTEGER,
    defaultValue: 1,
  },
  maximum_person: {
    type: DataTypes.INTEGER,
    defaultValue: 1,
  },
});

const RoomFacilities = sequelize.define('RoomFacilities', {});

const Guest = sequelize.define('Guest', {
  firstname: DataTypes.STRING,
  lastname: DataTypes.STRING,
  email: DataTypes.STRING,
  phonenumber: DataTypes.STRING,
  card_number: DataTypes.STRING,
  card_name: DataTypes.STRING,
});

const Booking = sequelize.define('Booking', {
  check_in_date: {
    type: DataTypes.DATE,
    allowNull: false,
  },
  check_out_date: {
    type: DataTypes.DATE,
    allowNull: false,
  },
});

// Определение связей
RoomType.hasMany(Room);
Room.belongsTo(RoomType);

Room.belongsToMany(Facilities, { through: RoomFacilities });
Facilities.belongsToMany(Room, { through: RoomFacilities });

Room.belongsTo(RoomAvailable);
RoomAvailable.hasMany(Room);

Room.belongsTo(Nutrition);
Nutrition.hasMany(Room);

Booking.belongsTo(Guest);
Guest.hasMany(Booking);

Booking.belongsTo(Room);
Room.hasMany(Booking);

module.exports = {
  RoomType,
  Facilities,
  Nutrition,
  RoomAvailable,
  Room,
  RoomFacilities,
  Guest,
  Booking,
  Admin,
};
