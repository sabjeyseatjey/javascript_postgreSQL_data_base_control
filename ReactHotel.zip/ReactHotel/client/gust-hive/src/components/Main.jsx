import { useState } from 'react'
import Navbar from './Navbar'
import Hero from './Hero'

function Main() {

  return (
    <>
     <Navbar/>
     <Hero></Hero>
    </>
  )
}

export default Main
