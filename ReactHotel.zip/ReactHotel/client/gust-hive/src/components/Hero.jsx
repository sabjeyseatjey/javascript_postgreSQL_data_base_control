import { useState } from 'react'
import video from '../assets/hotel.mp4'
import logo from '../../public/hexagon-with-left-arrow-svgrepo-com.svg'
import img_1 from '../assets/hotel_1.jpg'
import img_2 from '../assets/hotel_2.jpg'
import img_3 from '../assets/hotel_3.jpg'
import img_4 from '../assets/hotel_4.jpg'
import img_5 from '../assets/hotel_5.jpg'
import img_6 from '../assets/food_1.jpg'
import img_7 from '../assets/footer_1.jpg'


function Hero() {

  return (
    <>
        <div
        
        className=' justify-center overflow-x-hidden contrast-130 items-center w-[100%]'>
            <video className='object-cover  brightness-[75%] h-screen relative w-screen -z-10 top-0 left-0' src={video} width="100%" loop muted autoPlay></video>
            <div className=' text-white flex flex-col gap-8 inset-0 items-center   justify-center w-full text-center pt-[5%] absolute'>
            <img className='object-center' src={logo} width={85}></img>
            <p>GuestHive</p>
            <p>Отель</p>
            <h1 className='text-9xl'>Акунитесь в роскошь</h1>
            </div>
            
        </div>


        <div className='Main flex contrast-130 flex-col mt-[15%] '>
            <div className='img flex w-full px-12 justify-between'>
                <img className='object-left  w-[50%] ' src={img_1} alt="" />
                <img className='object-right w-[30%]' src={img_2} alt="" />
            </div>
            <div className='text-center m-[5%] mx-[30%]'>
                <h1 className='text-6xl'>Трудно найти, трудно уйти</h1>
                <p className='mt-[5%] px-[5%]'>Всего в нескольких часах езды от аэропорта. Световые годы вдали от толпы. Здесь вы найдете настоящий Бали. И небольшой курорт с большим видом, отличным рестораном и особым ощущением спокойствия. Добро пожаловать в Дамаи.</p>
            </div>
            <div className='img flex w-full px-12 justify-between'>
                <img className='object-left  w-[30%] ' src={img_4} alt="" />
                <img className='object-right w-[50%]' src={img_3} alt="" />
            </div>
        </div>

        <div style={{
            backgroundImage: `url(${img_5})`,
        }} className='mt-[15%] text-white items-center contrast-150 text-center flex content-center justify-center h-screen overflow-hidden bg-cover'>
            <div className='flex gap-[5%]'>
                <h1 className='text-9xl'>GUESTHIVE</h1>
                <h1 className='text-9xl'>GUESTHIVE  </h1>
                <h1 className='text-9xl'>GUESTHIVE  </h1>
                <h1 className='text-9xl'>GUESTHIVE  </h1>
            </div>

        </div>



        <div>
        <section id="main_section">
        <div
        
        className='w-full bg-left mt-[15%] py-16 '>
            <div className='max-w-[1240px] mx-auto grid md:grid-cols-2 '>
            <div className='text-black  flex flex-col md:mx-5 md:px-20 px-5 justify-center '>
                <h1 className=' md:text-5xl mb-5 sm:text-4xl text-2xl font-bold py-2 uppercase'>Отмеченная наградами кухня</h1>
                <p className='md:text-xl'> Едой в GuestHive легко наслаждаться. Простые блюда пивной и балийская классика. Органические овощи из собственных садов. Свежая рыба из Балийского моря. Аромат острова специй. Местная кухня, вдохновленная миром, завоевала международные награды и была включена в кулинарные книги.</p>
              </div>
              <div>
                <img src={img_6} alt="" />                
              </div>
              
            </div>
        </div>
    </section>
        </div>
        
        <div style={{
            backgroundImage: `url(${img_7})`,
        }} className='h-[200px] bg-cover   mt-[15%]'>
            <h1 className='text-white p-10 pt-[8%] text-center '>@GuestHive</h1>
        </div>
    </>
  )
}

export default Hero
