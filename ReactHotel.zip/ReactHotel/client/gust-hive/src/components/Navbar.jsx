import { useState } from 'react'
import { HiMenuAlt4 } from "react-icons/hi";
import logo from '../../public/hexagon-with-left-arrow-svgrepo-com.svg'
import { FiHexagon } from "react-icons/fi";
import { PiHexagonThin } from "react-icons/pi";


function Navbar() {

    const [nav, setNav] = useState(false)

    const handleNav = () => {
        setNav(!nav)
    }
    

  return (
    <>
    <div className='fixed z-10 text-white flex items-center justify-between gap-5 px-[10%] w-full h-[12%] border-b-[1px] bg-black/25 backdrop-blur-lg border-b-white'>
        <div className='men_b bg-slate-900 scale-[1.5] rounded-full cursor-pointer '>
        <HiMenuAlt4 onClick={handleNav} size={25} fill='white'/>

        </div>
        <div className='logo w-[5%] text-5xl cursor-pointer'>
            <h1>GuestHive</h1>
        </div>
        <div className='w-[10%] flex text-white px-4 rounded-full items-center  bg-slate-900 '>
            <button className='p-2 '>Book</button>
            <FiHexagon />

        </div>
    </div>
    <div className={!nav ? 'w-full duration-700 ease-in-out translate-y-[-100%] flex flex-col gap-[15%] items-center text-7xl justify-center text-white tex h-full fixed z-10 bg-slate-950' : 'w-full duration-700 ease-in-out translate-y-[0%] flex flex-col gap-[15%] items-center text-7xl justify-center text-white tex h-full fixed z-10 bg-slate-950'}>
        <div className='cursor-pointer '>
        <PiHexagonThin onClick={handleNav} size={50} fill='white' />
        </div>
        <div className='cursor-pointer'>
            <h1>Booking</h1>
        </div>
        <div className='cursor-pointer'>
            <h1>Stay</h1>
        </div>
    </div>
    </>
  )
}

export default Navbar
